package com.messenger;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.CacheLookup;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
	

public class Messenger_PageObject {

	
	

		
	WebDriver Driver;
		
		@FindBy(id = "email") 
		@CacheLookup
		WebElement Uname_Txt; 
		
		@FindBy(id="userNavigationLabel")
		@CacheLookup
		WebElement Account_Select; 
		
		@FindBy(xpath="//span[contains(text(),'Log Out')]")
		@CacheLookup
		WebElement Logout_Select; 
		
		
		
		@FindBy(id = "pass")
		@CacheLookup
		WebElement Pwd_Txt;
		
		@FindBy(id = "u_0_b")
		@CacheLookup
		WebElement SignInBtn;
		
		@FindBy(name="mercurymessages")
		@CacheLookup
		WebElement MessngerBtn; 
		
		
		@FindBy(xpath="//body/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/ul/li[2]/a[1]")
		@CacheLookup
		WebElement MsgBtn;
		
		@FindBy(xpath="//html//body//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//div//span//div//div//div//div//div//div//div")
		@CacheLookup
		WebElement Msg_txt;




		public Messenger_PageObject(WebDriver Driver) {
			this.Driver = Driver;
			PageFactory.initElements(Driver, this);
		
			
		}

		//Type text into the user name text box
		
		public void setUname_Txt(String UserName) {
			Uname_Txt.sendKeys(UserName);
		}

		// Type text into password field

		public void setPwd_Txt(String Password) {
			Pwd_Txt.sendKeys(Password);
		}
		
		//Click on sign in button..

		public void setSignInBtn() {
			SignInBtn.click();
		}
		
				
		public void setOpenMessenger() 
		{
		WebDriverWait wait = new WebDriverWait(Driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(MessngerBtn)).click();
			//MessngerBtn.click();
			
			
		}
		
		public void setmsg() 
		{
//		WebDriverWait wait = new WebDriverWait(Driver, 20);
//			wait.until(ExpectedConditions.elementToBeClickable(MsgBtn)).click();		
			MsgBtn.click();
			
		}
		
		public void setmsgtxt() 
		{
		WebDriverWait wait = new WebDriverWait(Driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(Msg_txt)).sendKeys("hii");		
			
			
		}
			
			
			
			
			
			public void setLogout_Select() throws InterruptedException  {
				Thread.sleep(3000);
				Account_Select.click();	
				Thread.sleep(3000);
				WebDriverWait wait1 = new WebDriverWait(Driver, 30);
				wait1.until(ExpectedConditions.elementToBeClickable(Logout_Select)).click();
			}
			
		}


