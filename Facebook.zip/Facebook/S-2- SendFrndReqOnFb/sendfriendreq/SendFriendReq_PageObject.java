package com.sendfriendreq;
//import org.openqa.selenium.By;
		import org.openqa.selenium.WebDriver;
		import org.openqa.selenium.WebElement;
		import org.openqa.selenium.support.CacheLookup;
		import org.openqa.selenium.support.FindBy;
		import org.openqa.selenium.support.PageFactory;
		import org.openqa.selenium.support.ui.ExpectedConditions;
		import org.openqa.selenium.support.ui.WebDriverWait;
		//import org.openqa.selenium.support.ui.ExpectedConditions;
		//import org.openqa.selenium.support.ui.Select;
		//import org.openqa.selenium.support.ui.WebDriverWait;

public class SendFriendReq_PageObject {
	
	
	

			WebDriver Driver;
			
			@FindBy(id = "email") 
			@CacheLookup
			WebElement Uname_Txt; 
			
			@FindBy(id="userNavigationLabel")
			@CacheLookup
			WebElement Account_Select; 
			
			@FindBy(xpath="//span[contains(text(),'Log Out')]")
			@CacheLookup
			WebElement Logout_Select; 
			
			
			
			@FindBy(id = "pass")
			@CacheLookup
			WebElement Pwd_Txt;
			
			
			
			@FindBy(id = "u_0_b")
			@CacheLookup
			WebElement SignInBtn;
			
			
			@FindBy(xpath= "//a[@name='requests']//div")
			@CacheLookup
			WebElement frndreqBtn;
			
			

			@FindBy(xpath= "//ul[1]//li[1]//div[1]//div[1]//div[1]//div[2]//div[2]//div[1]//div[1]//div[1]//div[1]//div[1]//button[1]")
			@CacheLookup
			WebElement addBtn;



			public SendFriendReq_PageObject(WebDriver Driver) {
				this.Driver = Driver;
				PageFactory.initElements(Driver, this);
			
				
			}

			//Type text into the user name text box
			
			public void setUname_Txt(String UserName) {
				Uname_Txt.sendKeys(UserName);
			}

			// Type text into password field

			public void setPwd_Txt(String Password) {
				Pwd_Txt.sendKeys(Password);
			}
			
			//Click on sign in button..

			public void setSignInBtn() {
				SignInBtn.click();
			}
			
					public void setfrndReq()  {
						
				WebDriverWait wait = new WebDriverWait(Driver, 20);
				wait.until(ExpectedConditions.elementToBeClickable(frndreqBtn)).click() ;
						///frndreqBtn.click();
				
			}
					
					public void setsendfrndReq()  {
						
						WebDriverWait wait = new WebDriverWait(Driver, 20);
						wait.until(ExpectedConditions.elementToBeClickable(addBtn)).click() ;
								//removeBtn.click();
						
					}
				
				
				
				public void setLogout_Select() throws InterruptedException  {
					Thread.sleep(3000);
					Account_Select.click();	
					Thread.sleep(3000);
					WebDriverWait wait1 = new WebDriverWait(Driver, 20);
					wait1.until(ExpectedConditions.elementToBeClickable(Logout_Select)).click();
				}
				


}
