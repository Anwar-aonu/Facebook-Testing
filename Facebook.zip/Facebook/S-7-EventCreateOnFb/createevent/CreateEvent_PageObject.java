package com.createevent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateEvent_PageObject {
	
			
	WebDriver Driver;
		
		@FindBy(id = "email") 
		@CacheLookup
		WebElement Uname_Txt; 
		
		@FindBy(id="userNavigationLabel")
		@CacheLookup
		WebElement Account_Select; 
		
		@FindBy(xpath="//span[contains(text(),'Log Out')]")
		@CacheLookup
		WebElement Logout_Select; 
		
		
		
		@FindBy(id = "pass")
		@CacheLookup
		WebElement Pwd_Txt;
		
		@FindBy(id = "u_0_b")
		@CacheLookup
		WebElement SignInBtn;
		
		 @FindBy(id="creation_hub_entrypoint")
		 @CacheLookup
		 WebElement createTab;

		    @FindBy(xpath ="//body/div/div/div/div/ul/li[5]/a[1]/span[1]/span[1]/div[1]")
		    @CacheLookup
		    WebElement eventBtn;
		    
		    @FindBy(xpath ="//input[@placeholder='Add a short, clear name']")
		    @CacheLookup
		    WebElement event_txt;
		    
		    @FindBy(xpath ="//button[contains(text(),'Create private event')]")
		    @CacheLookup
		    WebElement closeBtn;

		    
		    




		public CreateEvent_PageObject(WebDriver Driver) {
			this.Driver = Driver;
			PageFactory.initElements(Driver, this);
		
			
		}

		//Type text into the user name text box
		
		public void setUname_Txt(String UserName) {
			Uname_Txt.sendKeys(UserName);
		}

		// Type text into password field

		public void setPwd_Txt(String Password) {
			Pwd_Txt.sendKeys(Password);
		}
		
		//Click on sign in button..

		public void setSignInBtn() {
			SignInBtn.click();
		}
		
		public void setcreate() throws InterruptedException{

			
//	        WebDriverWait wait = new WebDriverWait(Driver,20);
//	        wait.until(ExpectedConditions.elementToBeClickable(createTab)).click();
	        createTab.click();
	       /// Thread.sleep(2000);
	
			
	    }
		
public void setevent(){

			
	        WebDriverWait wait = new WebDriverWait(Driver,20);
	        wait.until(ExpectedConditions.elementToBeClickable(eventBtn)).click();
	
			
	    }

public void setname()
{

	
    WebDriverWait wait = new WebDriverWait(Driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(event_txt)).sendKeys("Testing");

	
}

public void setclose()
{

	
    WebDriverWait wait = new WebDriverWait(Driver,20);
    wait.until(ExpectedConditions.elementToBeClickable(closeBtn)).click();

	
}




		
			public void setLogout_Select() throws InterruptedException  {
				Thread.sleep(3000);
				Account_Select.click();	
				Thread.sleep(3000);
				WebDriverWait wait1 = new WebDriverWait(Driver, 20);
				wait1.until(ExpectedConditions.elementToBeClickable(Logout_Select)).click();
			}
			
		}


		
		
		



		
		




	
	


			
			
			
			
			

		





