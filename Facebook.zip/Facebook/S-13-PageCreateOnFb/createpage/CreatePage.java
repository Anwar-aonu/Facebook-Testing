package com.createpage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CreatePage {
	
	
	WebDriver Driver;
	CreatePage_PageObject FacebookO;
	
	@BeforeTest
	public void set_Up() {
				
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Aonu\\Downloads\\chromedriver\\chromedriver.exe");  
		Driver = new ChromeDriver();
        FacebookO = new CreatePage_PageObject(Driver);
		Driver.get("https://www.facebook.com/");
		Driver.manage().window().maximize();
	}
	
	@AfterTest
	public void tear_Down()  {
		
		Driver.close();
	}
	
	@Parameters({"Username" , "password"})
	@Test(priority = 1)
	public void LoginAction(String Username, String password) throws InterruptedException  {
		
		
		FacebookO.setUname_Txt(Username);
				
		FacebookO.setPwd_Txt(password);
		
		FacebookO.setSignInBtn();
		Thread.sleep(10000);
		
	}
	
		@Test(priority = 2)
	public void create() throws InterruptedException
	{  
		FacebookO.setcreate();
		Thread.sleep(10000);


		
	}
		
		@Test(priority = 3)
		public void page() throws InterruptedException
		{  
			FacebookO.setpage();
			Thread.sleep(10000);


			
		}

	

	
	@Test(priority = 4)
	public void LogoutAction() throws InterruptedException
	{  

		FacebookO.setLogout_Select();
		Thread.sleep(30000);

	}




}
