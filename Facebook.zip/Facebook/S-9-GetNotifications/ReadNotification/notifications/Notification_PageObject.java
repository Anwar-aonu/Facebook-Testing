package com.notifications;

import org.openqa.selenium.By;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.support.CacheLookup;
	import org.openqa.selenium.support.FindBy;
	import org.openqa.selenium.support.PageFactory;
	import org.openqa.selenium.support.ui.ExpectedConditions;
	import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
	

public class Notification_PageObject {
	
	WebDriver Driver;
		
		@FindBy(id = "email") 
		@CacheLookup
		WebElement Uname_Txt; 
		
		@FindBy(id="userNavigationLabel")
		@CacheLookup
		WebElement Account_Select; 
		
		@FindBy(xpath="//span[contains(text(),'Log Out')]")
		@CacheLookup
		WebElement Logout_Select; 
		
		
		
		@FindBy(id = "pass")
		@CacheLookup
		WebElement Pwd_Txt;
		
		
		
		@FindBy(id = "u_0_b")
		@CacheLookup
		WebElement SignInBtn;
		
		
		@FindBy(xpath= "//a[@name='notifications']//div")
		@CacheLookup
		WebElement notificationBtn;





		public Notification_PageObject(WebDriver Driver) {
			this.Driver = Driver;
			PageFactory.initElements(Driver, this);
		
			
		}

		//Type text into the user name text box
		
		public void setUname_Txt(String UserName) {
			Uname_Txt.sendKeys(UserName);
		}

		// Type text into password field

		public void setPwd_Txt(String Password) {
			Pwd_Txt.sendKeys(Password);
		}
		
		//Click on sign in button..

		public void setSignInBtn() throws InterruptedException {
			SignInBtn.click();
			Thread.sleep(20000);
		}
		
		public void setReadNotification() throws InterruptedException  {
			WebDriverWait wait = new WebDriverWait(Driver, 30);
			wait.until(ExpectedConditions.elementToBeClickable(notificationBtn)).click();
			
			
			Thread.sleep(20000);
			Reporter.log(Driver.findElement(By.xpath("//body/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/div/ul/li/div/ul/li[1]/div[1]/div[1]/a[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/div[1]/span[1]")).getText());
		}
			
			
			
			public void setLogout_Select() throws InterruptedException  {
				Thread.sleep(1000);
				Account_Select.click();	
				Thread.sleep(1000);
				WebDriverWait wait1 = new WebDriverWait(Driver, 20);
				wait1.until(ExpectedConditions.elementToBeClickable(Logout_Select)).click();
			}
			

}
